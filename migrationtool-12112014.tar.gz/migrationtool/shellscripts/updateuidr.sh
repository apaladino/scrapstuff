#!/bin/bash


email=""
systemId=""

targetEnv=""

# UIDR SERVICE HOSTS 
edSvc="ed1.uidsvc.qai.expertcity.com"
rcSvc="rc1.uidsvc.qai.expertcity.com"
stageSvc="stage.uidsvc.las.expertcity.com"
targetEnv="ed"
targetSvc="$edSvc";


# set email
if [ "$1" != "" ]; then
	email=$1
else
    echo "USAGE: getUserSystemId <email> <environment (Optional) [ed (default),rc,stage]>"
    exit
fi


if [ "$2" != "" ]; then
	targetEnv="$2"
fi

if [ "$3" != "" ]; then
	systemId="$3"
fi

# set environment
if [ $targetEnv == "ed" ]; then
	targetSvc="$edSvc"
	
fi

if [ $targetEnv == "rc" ]; then
	targetSvc="$rcSvc"
fi
if [ $targetEnv == "stage" ]; then
	targetSvc="$stageSvc"
fi


echo "deleting systemId for user $email"
curl -v -k -X DELETE "http://$targetSvc/useridresolver/rest/user?email=$email"

echo "adding systemId for user $email"
curl -v -k -X POST "http://$targetSvc/useridresolver/rest/user?email=$email&systemId=$systemId"


