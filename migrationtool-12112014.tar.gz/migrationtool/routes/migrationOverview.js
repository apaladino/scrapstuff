var request = require('request');
var _exec = require('child_process').exec;
var log4js = require('log4js');
var logger = log4js.getLogger("dev");

function logRequest(type, req){

    logger.info("Request Received. TYPE: " + type +  ", PATH: " + req.path + ", EXT-IP:" + req.ip );
}

exports.getTriageCountsView = function(req, res){

    var title = 'Triage Overview';
    console.log("GET /overview/triage");
    res.render('triage', { title : title });
};

exports.getTriageCountsWeek = function(req, res){

    var ipAddr = req.headers["x-forwarded-for"];

    console.log("GET /overview/triage");
    console.log("GET " + req.path + " - External IP: " + req.ip);
    logRequest("GET", req);

    var command = 'java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true triageCountsWeek';

    var Counts = function(count, status, basePlan, startTime, partition){
        this.count = count;
        this.status = status;
        this.basePlan = basePlan;
        this.startTime = startTime;
        this.partition = partition;
    }

    _exec(command, {maxBuffer: 5000*1024}, function(e, stdout, stderr) {
        if (e) {
            console.log("Unexpected error: " + e);
        }
        var output = stdout;
        var lines = output.split("\n");
        var countsStarted = false;
        var counts = [];

        for(var i=0; i < lines.length; i++){
            var line = lines[i];

            // process migration counts data
            if(line.indexOf('##-TRIAGE COUNTS WEEK-##') >= 0){
                countsStarted = true;
                console.log("countsStarted = true");
                continue;
            }
            if(line.indexOf('##-TRIAGE COUNTS WEEK END-##') >= 0){
                countsStarted = false;
                console.log("countsStarted = false");
                continue;
            }

            if(countsStarted){
                if(line.indexOf('##-COLS-') >= 0){
                    console.log("Skipping columns line");
                    continue;
                }
                var tokens = line.split(',');


                counts.push(new Counts(tokens[0], tokens[1], tokens[2], tokens[3], tokens[4]));
            }


        }// end for loop


        // render migration overview page
        res.render('triageCountsWeek', { counts: counts });
    });
};


exports.getStats = function(req, res){

    /*
     java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true
     */;

    var command = 'java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true';

    logRequest("GET", req);

    var MigrationCount = function(count, status, workflow){
        this.count = count;
        this.status = status;
        this.workflow = workflow;
        this.toString = function(){
            return "count: " + this.count + ", status: " + this.status + ", workflow: " + this.workflow;
        }
    }
    var AugustMigrationCount = function(count, status, workflow, starttime){
        this.count = count;
        this.status = status;
        this.workflow = workflow;
        this.starttime = starttime;
        this.toString = function(){
            return "count: " + this.count + ", status: " + this.status + ", workflow: " + this.workflow + ", starttime: " + this.starttime;
        }
    }

    var July29MigrationCount = function(count, status, bundle, partition){
        this.count = count;
        this.bundle = bundle;
        this.status = status;
        this.partition = partition;
    }

    var AccountCount = function(count, name, partition){
        this.count = count;
        this.name = name;
        this.partition=partition;
    }

    var AccountStatusCount = function(count, name, partition, status){
        this.count = count;
        this.name = name;
        this.partition=partition;
        this.status=status;
    }

    var CountData = function(name, count){
        this.name = name;
        this.count = count;
    }

    var ErrorCount = function(count, err_msg, service){
        this.count = count;
        this.err_msg = err_msg;
        this.service = service;
    }


    _exec(command, {maxBuffer: 5000*1024}, function(e, stdout, stderr) {
        if (e) {
            console.log("Unexpected error: " + e);

        }
        var output = stdout;
        var lines = output.split("\n");
        var migCountsStarted = false;
        var accountsCountsStarted = false;
        var accountStatusStarted = false;
        var migrationCounts = [];
        var accountsCounts = [];
        var accountStatusCounts = [];
        var sinceJuly29Counts = [];
        var sinceJuly29CountsStarted = false;

        for(var i=0; i < lines.length; i++){
            var line = lines[i];

            // process migration counts data
            if(line.indexOf('##-MIGRATION COUNTS-##') >= 0){
                migCountsStarted = true;
                console.log("migCountsStarted = true");
                continue;
            }
            if(line.indexOf('##-MIGRATION COUNTS END-##') >= 0){
                migCountsStarted = false;
                console.log("migCountsStarted = false");
                continue;
            }

            if(line.indexOf('##-SINCE JULY 29 2014-##') >= 0){
                sinceJuly29CountsStarted = true;
                console.log("sinceJuly29Started = true");
                continue;
            }

            if(migCountsStarted){
                if(line.indexOf('##-COLS-') >= 0){
                    console.log("Skipping columns line");
                    continue;
                }
                console.log("*: " + line);
                var tokens = line.split(',');
                migrationCounts.push(new MigrationCount(tokens[0], tokens[1], tokens[2]));
            }

            if(line.indexOf('##-ACCOUNTS STATUS COUNTS-##') >= 0){
                accountStatusStarted = true;
                console.log("accountStatusStarted = true");
                continue;
            }

            if(line.indexOf('##-ACCOUNTS STATUS COUNTS END-##') >= 0){
                accountStatusStarted = false;
                console.log("accountStatusStarted = false");
                continue;
            }

            if(line.indexOf('##-SINCE JULY 29 2014 END-##') >= 0){
                sinceJuly29CountsStarted = false;
                console.log("sinceJuly29Started = false");
                continue;
            }

            if(sinceJuly29CountsStarted){
                if(line.indexOf('##-COLS-') >= 0){
                    console.log("Skipping columns line");
                    continue;
                }
                var tokens = line.split(",");
                sinceJuly29Counts.push(new July29MigrationCount(tokens[0], tokens[1], tokens[2].replace('####', ','), tokens[3]));
            }

            if(accountStatusStarted){
                if(line.indexOf('##-COLS-') >= 0){
                    console.log("Skipping columns line");
                    continue;
                }
                var tokens = line.split(",");
                console.log("^^^ " + tokens[1].replace('####', ','));
                accountStatusCounts.push(new AccountStatusCount(tokens[0], tokens[1].replace('####', ','), tokens[2], tokens[3]));
            }

        }// end for loop


        var accountStatusTotals = new Object();

        for(var i=0; i < accountStatusCounts.length; i++){
            var name = accountStatusCounts[i].name;
            var countStr = accountStatusCounts[i].count;
            if(typeof accountStatusTotals[name] == 'undefined'){
                accountStatusTotals[name] = parseInt(countStr);
            }else{
                var count = accountStatusTotals[name];
                count = count + parseInt(countStr);
                accountStatusTotals[name] = count;
            }
        }

        console.log("AcountStatusTotals: " + JSON.stringify(accountStatusTotals));

        // render migration overview page
        res.render('overview', { migrationCounts: migrationCounts,
            accountStatusCounts: accountStatusCounts,
            accountStatusTotals: accountStatusTotals,
            sinceJuly29Counts: sinceJuly29Counts
        });
    });
}

exports.getMigratedLast30Days = function(req, res){

    /*
     java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true
     */;
    logRequest("GET", req);

    var command = 'java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true migratedLast30Days';

    var AugustMigrationCount = function(count, status, workflow, starttime){
        this.count = count;
        this.status = status;
        this.workflow = workflow;
        this.starttime = starttime;
        this.toString = function(){
            return "count: " + this.count + ", status: " + this.status + ", workflow: " + this.workflow + ", starttime: " + this.starttime;
        }
    }

    _exec(command, {maxBuffer: 5000*1024}, function(e, stdout, stderr) {
        if (e) {
            console.log("Unexpected error: " + e);

        }
        var output = stdout;
        var lines = output.split("\n");
        var augustCountsStarted = false;
        var augustCounts = [];

        for(var i=0; i < lines.length; i++){
            var line = lines[i];

            // process migration counts data
            if(line.indexOf('##-SINCE AUGUST 1 2014-##') >= 0){
                augustCountsStarted = true;
                console.log("Counts since August 1 2014 started");
                continue;
            }

            if(line.indexOf('##-SINCE AUGUST 1 2014 END-##') >= 0){
                augustCountsStarted = false;
                console.log("augustCountsStarted = false");
                continue;
            }

            if(augustCountsStarted){
                if(line.indexOf('##-COLS-') >= 0){
                    console.log("Skipping columns line");
                    continue;
                }
                console.log("*: " + line);
                var tokens = line.split(',');
                augustCounts.push(new AugustMigrationCount(tokens[0], tokens[1], tokens[2], tokens[3]));
            }

        }// end for loop


        console.log("redirecting to migratedlastmonth view");
        // render migration overview page
        res.render('migratedlastmonth', {
            augustMigrationCounts: augustCounts
        });
    });

}

exports.getMigrationErrors = function(req, res){

    logRequest("GET", req);
    /*
     java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true
     */;

    var command = 'java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true migrationErrors';


    var ErrorCount = function(count, err_msg, service){
        this.count = count;
        this.err_msg = err_msg;
        this.service = service;
    }


    _exec(command, {maxBuffer: 5000*1024}, function(e, stdout, stderr) {
        if (e) {
            console.log("Unexpected error: " + e);

        }
        var output = stdout;
        var lines = output.split("\n");
        var errorCountsStarted = false;
        var errorCounts = [];

        for(var i=0; i < lines.length; i++){
            var line = lines[i];

            if(line.indexOf('##-ERRORS-##') >= 0){
                errorCountsStarted = true;
                console.log("Error Counts Started");
                continue;
            }

            if(line.indexOf('##-ERRORS END-##') >= 0){
                errorCountsStarted = false;
                console.log("Error Counts ended");
                continue;
            }

            if(errorCountsStarted){
                if(line.indexOf('##-COLS-') >= 0){
                    console.log("Skipping columns line");
                    continue;
                }
                var tokens = line.split(",");
                errorCounts.push(new ErrorCount(tokens[0], tokens[1], tokens[2]));
            }

        }// end for loop


        // render migration overview page
        res.render('migrationErrors', {
            errorCounts: errorCounts
        });
    });
}

exports.getCountsSinceJuly = function(req, res){

    logRequest("GET", req);
    /*
     java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true
     */;

    var command = 'java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true countsSinceJuly';

    var July29MigrationCount = function(count, status, bundle, partition){
        this.count = count;
        this.bundle = bundle;
        this.status = status;
        this.partition = partition;
    }

    _exec(command, {maxBuffer: 5000*1024}, function(e, stdout, stderr) {
        if (e) {
            console.log("Unexpected error: " + e);

        }
        var output = stdout;
        var lines = output.split("\n");
        var sinceJuly29Counts = [];
        var sinceJuly29CountsStarted = false;

        for(var i=0; i < lines.length; i++){
            var line = lines[i];

            if(line.indexOf('##-SINCE JULY 29 2014-##') >= 0){
                sinceJuly29CountsStarted = true;
                console.log("sinceJuly29Started = true");
                continue;
            }

            if(line.indexOf('##-SINCE JULY 29 2014 END-##') >= 0){
                sinceJuly29CountsStarted = false;
                console.log("sinceJuly29Started = false");
                continue;
            }

            if(sinceJuly29CountsStarted){
                if(line.indexOf('##-COLS-') >= 0){
                    console.log("Skipping columns line");
                    continue;
                }
                var tokens = line.split(",");
                sinceJuly29Counts.push(new July29MigrationCount(tokens[0], tokens[1], tokens[2].replace('####', ','), tokens[3]));
            }

        }// end for loop


        // render migration overview page
        res.render('sincejulycounts', {
            sinceJuly29Counts: sinceJuly29Counts
        });
    });
}

exports.getTriageRollbacks = function(req, res){

    logRequest("GET", req);

    var command = 'java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true triageRollbacks';

    var Rollback = function(starttime, accountkey, bundles, errMsg, service, partition){
        this.starttime = starttime;
        this.accountkey = accountkey;
        this.bundles = bundles;
        this.errMsg = errMsg;
        this.service = service;
        this.partition = partition;
    };

    _exec(command, {maxBuffer: 5000*1024}, function(e, stdout, stderr) {
        if (e) {
            console.log("Unexpected error: " + e);
        }
        var output = stdout;
        var lines = output.split("\n");
        var migCountsStarted = false;
        var rollbacksStarted = false;
        var rollbacks = [];

        for(var i=0; i < lines.length; i++){
            var line = lines[i];

            if((line.indexOf('##') >= 0)){
                console.log("*:" +  (line.indexOf('##-ROLLBACKS-##') >= 0) + '^' + line + '^');
            }

            // process migration counts data
            if(line.indexOf('##-ROLLBACKS-##') >= 0){
                rollbacksStarted = true;
                console.log("rollbacksStarted = true");
                continue;
            }
            if(line.indexOf('##-ROLLBACKS END-##') >= 0){
                rollbacksStarted = false;
                console.log("rollbacksStarted = false");
                continue;
            }

            if(rollbacksStarted){
                if(line.indexOf('##-COLS-') >= 0){
                    console.log("Skipping columns line");
                    continue;
                }
                var tokens = line.split(',');


                rollbacks.push(new Rollback(tokens[0], tokens[1], tokens[2], tokens[3], tokens[4], tokens[5]));
            }


        }// end for loop


        // render migration overview page
        res.render('triageRollbacks', { rollbacks: rollbacks });
    });
}

exports.getTriageCounts = function(req, res){

    logRequest("GET", req);

    /*
     java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true
     */;
    var isPassingRequest = req.query.showPassing;

    var command = 'java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true triageCounts';

    var PassingCandidate = function(partition, accountkey, status, commerceSvcStatus, commerceSvcErrmsg,
            g2wSvcStatus,g2wSvcErrorMsg, g2tSvcStatus, g2tSvcErrmsg, bundletype, candidateRejectedCount, rejectingFilter,
            bundleName, candidateCreatedTime){
        this.partition = partition;
        this.accountkey = accountkey;
        this.status = status;
        this.commerceSvcStatus = commerceSvcStatus;
        this.commerceSvcErrmsg = commerceSvcErrmsg;
        this.g2wSvcStatus = g2wSvcStatus;
        this.g2wSvcErrorMsg = g2wSvcErrorMsg;
        this.g2tSvcStatus = g2tSvcStatus;
        this.g2tSvcErrmsg = g2tSvcErrmsg;
        this.bundletype = bundletype;
        this.candidateRejectedCount = candidateRejectedCount;
        this.rejectingFilter = rejectingFilter;
        this.bundleName = bundleName;
        this.candidateCreatedTime = candidateCreatedTime;
    }

    var RejectedCandidate = function(partition, accountkey, status, candidateRejectedCount, rejectingFilter,
            bundleName, bundleType, candidateCreatedTime){
        this.partition = partition;
        this.accountkey = accountkey;
        this.status = status;
        this.bundleType = bundleType;
        this.candidateRejectedCount = candidateRejectedCount;
        this.rejectingFilter = rejectingFilter;
        this.bundleName = bundleName;
        this.candidateCreatedTime = candidateCreatedTime;
    }


    _exec(command, {maxBuffer: 5000*1024}, function(e, stdout, stderr) {
        if (e) {
            console.log("Unexpected error: " + e);
        }
        var output = stdout;
        var lines = output.split("\n");
        var migCountsStarted = false;
        var passingCandidatesStarted = false;
        var rejectedCandidatesStarted = false;
        var passingCandidates = [];
        var rejectedCandidates = [];

        for(var i=0; i < lines.length; i++){
            var line = lines[i];

            //console.log("*1? : " + (line.indexOf('REJECTED CANDIDATES 7 DAYS-' && !isPassingRequest) >= 0));
            if((line.indexOf('##') >= 0)){
                console.log("*:" +  (line.indexOf('##-REJECTED CANDIDATES 7 DAYS-##') >= 0) + '^' + line + '^' + isPassingRequest);
            }

            // process migration counts data
            if(line.indexOf('##-PASSING CANDIDATES 7 DAYS-##') >= 0){
                passingCandidatesStarted = true;
                console.log("passingCandidatesStarted = true");
                continue;
            }
            if(line.indexOf('#-PASSING CANDIDATES 7 DAYS END-##') >= 0){
                passingCandidatesStarted = false;
                console.log("passingCandidatesStarted = false");
                continue;
            }

            if(line.indexOf('##-REJECTED CANDIDATES 7 DAYS-##') >= 0){
                rejectedCandidatesStarted = true;
                console.log("rejectedCandidatesStarted = true");
                continue;
            }

            if(line.indexOf('##-REJECTED CANDIDATES 7 DAYS-##') >= 0){
                rejectedCandidatesStarted = false;
                console.log("rejectedCandidatesStarted = false");
                continue;
            }


            if(passingCandidatesStarted){
                if(line.indexOf('##-COLS-') >= 0){
                    console.log("Skipping columns line");
                    continue;
                }
                var tokens = line.split(',');
                console.log("**: " + JSON.stringify(tokens, null, 2));

                var candidate = new PassingCandidate();
                candidate.partition = tokens[0];
                candidate.accountkey = tokens[1];
                candidate.status=tokens[2];
                candidate.commerceSvcStatus = tokens[3];
                candidate.commerceSvcErrmsg = tokens[4];
                candidate.g2wSvcStatus = tokens[5];
                candidate.g2wSvcErrorMsg = tokens[6];
                candidate.g2tSvcStatus = tokens[7];
                candidate.g2tSvcErrmsg = tokens[8];
                candidate.bundletype = tokens[9];
                candidate.candidateRejectedCount = tokens[10];
                candidate.rejectingFilter = tokens[11];
                candidate.bundleName = tokens[11];
                candidate.bundleType= tokens[12];
                candidate.candidateCreatedTime = tokens[13];

                passingCandidates.push(candidate);

            }

            if(rejectedCandidatesStarted){

                /*
                 ##-COLS-##PARTITION,ACCOUNTKEY,MIGRATION_STATUS,CANDIDATEREJECTEDCOUNT,REJECTINGFILTER,BUNDLENAME,BUNDLETYPE,CANDIDATECREATEDTIME,

                 function(partition, accountkey, status, candidateRejectedCount, rejectingFilter,
                 bundleName, bundleType, candidateCreatedTime){
                 */
                if(line.indexOf('##-COLS-') >= 0){
                    console.log("Skipping columns line");
                    continue;
                }
                var tokens = line.split(',');

                rejectedCandidates.push(new RejectedCandidate(tokens[0], tokens[1], tokens[2], tokens[3],
                    tokens[4], tokens[5], tokens[6], tokens[7]));
            }

        }// end for loop


        //console.log("rejected candidates: " + JSON.stringify(rejectedCandidates));

        // render migration overview page
        res.render('triageView', { passingCandidates: passingCandidates,
           rejectedCandidates : rejectedCandidates,
           showPassingCandidates : isPassingRequest
        });
    });
}


exports.getTriageCompletedView = function(req, res){

    logRequest("GET", req);
    var command = 'java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true triageCompleted';

    var Completed = function(accountKey, basePlan, partition, numFailed, startTime, completedTime){
        this.accountkey= accountKey;
        this.basePlan = basePlan;
        this.partition = partition;
        this.numFailed = numFailed;
        this.startTime = startTime;
        this.completedTime = completedTime;
    }

    _exec(command, {maxBuffer: 5000*1024}, function(e, stdout, stderr) {
        if (e) {
            console.log("Unexpected error: " + e);
        }
        var output = stdout;
        var lines = output.split("\n");
        var migCountsStarted = false;
        var completedStarted = false;
        var completed = [];

        for(var i=0; i < lines.length; i++){
            var line = lines[i];

            if((line.indexOf('##') >= 0)){
                console.log("*:" +  (line.indexOf('##-TRIAGE COMPLETED-##') >= 0) + '^' + line + '^');
            }

            // process migration counts data
            if(line.indexOf('##-TRIAGE COMPLETED-##') >= 0){
                completedStarted = true;
                console.log("completedStarted = true");
                continue;
            }
            if(line.indexOf('##-TRIAGE COMPLETED END-##') >= 0){
                completedStarted = false;
                console.log("completedStarted = false");
                continue;
            }

            if(completedStarted){
                if(line.indexOf('##-COLS-') >= 0){
                    console.log("Skipping columns line");
                    continue;
                }
                var tokens = line.split(',');


                completed.push(new Completed(tokens[0], tokens[1], tokens[2], tokens[3], tokens[4], tokens[5]));
            }


        }// end for loop


        // render migration overview page
        res.render('triageCompleted', { completed: completed });
    });
}

exports.getTriageCompletedPerHour = function(req, res){

    logRequest("GET", req);
    var command = 'java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true completedPerHour';

    var CompletedPerHour = function(count, completed, partition){
        this.count = count;
        this.completed=completed;
        this.partition=partition;
    }

    _exec(command, {maxBuffer: 5000*1024}, function(e, stdout, stderr) {
        if (e) {
            console.log("Unexpected error: " + e);
        }
        var output = stdout;
        var lines = output.split("\n");
        var migCountsStarted = false;
        var completedStarted = false;
        var completed = [];

        for(var i=0; i < lines.length; i++){
            var line = lines[i];


            // process migration counts data
            if(line.indexOf('##-COMPLETED PER HOUR-##') >= 0){
                completedStarted = true;
                console.log("completedStarted = true");
                continue;
            }
            if(line.indexOf('##-COMPLETED PER HOUR END-##') >= 0){
                completedStarted = false;
                console.log("completedStarted = false");
                continue;
            }

            if(completedStarted){
                if(line.indexOf('##-COLS-') >= 0){
                    console.log("Skipping columns line");
                    continue;
                }
                var tokens = line.split(',');

                completed.push(new CompletedPerHour(tokens[0], tokens[1], tokens[2]));
            }


        }// end for loop


        // render migration overview page
        res.render('triageCompletedPerHour', { completed: completed });
    });
}


exports.getTriageCandidatesPerHour = function(req, res){

    logRequest("GET", req);
    var command = 'java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true candidatesPerHour';

    var CandidatesPerHour = function(count, createtime){
        this.count = count;
        this.createtime = createtime;
    }

    _exec(command, {maxBuffer: 5000*1024}, function(e, stdout, stderr) {
        if (e) {
            console.log("Unexpected error: " + e);
        }
        var output = stdout;
        var lines = output.split("\n");
        var migCountsStarted = false;
        var completedStarted = false;
        var candidates = [];

        for(var i=0; i < lines.length; i++){
            var line = lines[i];


            // process migration counts data
            if(line.indexOf('##-CANDIDATE PER HOUR-##') >= 0){
                completedStarted = true;
                console.log("completedStarted = true");
                continue;
            }
            if(line.indexOf('##-CANDIDATE PER HOUR END-##') >= 0){
                completedStarted = false;
                console.log("completedStarted = false");
                continue;
            }

            if(completedStarted){
                if(line.indexOf('##-COLS-') >= 0){
                    console.log("Skipping columns line");
                    continue;
                }
                var tokens = line.split(',');

                candidates.push(new CandidatesPerHour(tokens[0], tokens[1]));
            }


        }// end for loop


        // render migration overview page
        res.render('triageCandidatesPerHour.ejs', { candidates: candidates });
    });
}


exports.getTriageCandidateCounts = function(req, res){

    logRequest("GET", req);
    var command = 'java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true candidateCountsPerDay';

    var CandidateCounts = function(count, bundles, createtime, partition, migration_status){
        this.count = count;
        this.bundles = bundles;
        this.createtime = createtime;
        this.partition = partition;
        this.migration_status=migration_status;
    }

    _exec(command, {maxBuffer: 5000*1024}, function(e, stdout, stderr) {
        if (e) {
            console.log("Unexpected error: " + e);
        }
        var output = stdout;
        var lines = output.split("\n");
        var migCountsStarted = false;
        var completedStarted = false;
        var candidates = [];

        for(var i=0; i < lines.length; i++){
            var line = lines[i];


            // process migration counts data
            if(line.indexOf('##-CANDIDATE COUNTS PER DAY-##') >= 0){
                completedStarted = true;
                console.log("completedStarted = true");
                continue;
            }
            if(line.indexOf('##-CANDIDATE COUNTS PER DAY END-##') >= 0){
                completedStarted = false;
                console.log("completedStarted = false");
                continue;
            }

            if(completedStarted){
                if(line.indexOf('##-COLS-') >= 0){
                    console.log("Skipping columns line");
                    continue;
                }
                var tokens = line.split(',');

                candidates.push(new CandidateCounts(tokens[0], tokens[1], tokens[2], tokens[3], tokens[4]));
            }


        }// end for loop


        console.log(JSON.stringify(candidates, null, 2));

        // render migration overview page
        res.render('triageCandidatesCounts.ejs', { candidates: candidates });
    });
}



exports.getMissingSRPCandidates = function(req, res){

    logRequest("GET", req);
    var command = 'java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true missingSRP';

    var CandidateMember = function(email, userkey, accountkey, createtime, rejected, partition){
        this.email = email;
        this.userkey = userkey;
        this.accountkey = accountkey;
        this.createtime = createtime;
        this.rejected = rejected;
        this.partition = partition;
    }

    _exec(command, {maxBuffer: 5000*1024}, function(e, stdout, stderr) {
        if (e) {
            console.log("Unexpected error: " + e);
        }
        var output = stdout;
        var lines = output.split("\n");
        var migCountsStarted = false;
        var completedStarted = false;
        var candidates = [];

        for(var i=0; i < lines.length; i++){
            var line = lines[i];


            // process migration counts data
            if(line.indexOf('##-MISSING SRP INFO-##') >= 0){
                completedStarted = true;
                console.log("completedStarted = true");
                continue;
            }
            if(line.indexOf('##-MISSING SRP INFO END-##') >= 0){
                completedStarted = false;
                console.log("completedStarted = false");
                continue;
            }

            if(completedStarted){
                if(line.indexOf('##-COLS-') >= 0){
                    console.log("Skipping columns line");
                    continue;
                }
                var tokens = line.split(',');

                candidates.push(new CandidateMember(tokens[0], tokens[1], tokens[2], tokens[3], tokens[4], tokens[5]));
            }


        }// end for loop



        // render migration overview page
        res.render('triageCandidatesMissingSRP.ejs', { candidates: candidates });
    });
}



exports.getNewAccountsSinceJuly = function(req, res){

    logRequest("GET", req);
    var command = 'java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true newAccountsSinceJuly';

    var AccountData = function(count, type, createtime, partition){
        this.count = count;
        this.type = type;
        this.createtime=createtime;
        this.partition = partition;
    }

    _exec(command, {maxBuffer: 5000*1024}, function(e, stdout, stderr) {
        if (e) {
            console.log("Unexpected error: " + e);
        }
        var output = stdout;
        console.log(output);
        var lines = output.split("\n");
        var migCountsStarted = false;
        var completedStarted = false;
        var accounts = [];

        for(var i=0; i < lines.length; i++){
            var line = lines[i];

            // process migration counts data
            if(line.indexOf('##-NEW ACCOUNTS SINCE JULY-##') >= 0){
                completedStarted = true;
                console.log("completedStarted = true");
                continue;
            }
            if(line.indexOf('##-NEW ACCOUNTS SINCE JULY END-##') >= 0){
                completedStarted = false;
                console.log("completedStarted = false");
                continue;
            }

            if(completedStarted){
                if(line.indexOf('##-COLS-') >= 0){
                    console.log("Skipping columns line");
                    continue;
                }
                var tokens = line.split(',');

                accounts.push(new AccountData(tokens[0], tokens[1], tokens[2], tokens[3]));
            }


        }// end for loop



        // render migration overview page
        res.render('newAccountsSinceJuly.ejs', { accounts: accounts });
    });
}



exports.getHistorySyncCounts = function(req, res){

    logRequest("GET", req);
    var command = 'java -jar schema-snapshot-1.0-SNAPSHOT-jar-with-dependencies.jar jdbc:oracle:thin:@//odsdb1.ops.expertcity.com:1521/odsprod apaladino apaladino1234 ods-snapshot true historySyncCounts';

    var SyncData = function(count, sync_days, migratedtime, partition){
        this.count = count;
        this.sync_days = sync_days;
        this.migratedtime = migratedtime;
        this.partition = partition;
    }

    _exec(command, {maxBuffer: 5000*1024}, function(e, stdout, stderr) {
        if (e) {
            console.log("Unexpected error: " + e);
        }
        var output = stdout;
        console.log(output);
        var lines = output.split("\n");
        var migCountsStarted = false;
        var completedStarted = false;
        var counts = [];

        for(var i=0; i < lines.length; i++){
            var line = lines[i];

            // process migration counts data
            if(line.indexOf('##-HISTORY SYNC COUNTS-##') >= 0){
                completedStarted = true;
                console.log("completedStarted = true");
                continue;
            }
            if(line.indexOf('##-HISTORY SYNC COUNTS END-##') >= 0){
                completedStarted = false;
                console.log("completedStarted = false");
                continue;
            }

            if(completedStarted){
                if(line.indexOf('##-COLS-') >= 0){
                    console.log("Skipping columns line");
                    continue;
                }
                var tokens = line.split(',');

                counts.push(new SyncData(tokens[0], tokens[1], tokens[2], tokens[3]));
            }


        }// end for loop



        // render migration overview page
        res.render('historySyncCounts.ejs', { counts: counts });
    });
}

