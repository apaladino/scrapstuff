
/*
 * GET user status.
 */
var request = require('request');
var log4js = require('log4js');
var logger = log4js.getLogger("dev");
var adminPW = "iams0happy";

var exec = require('child_process').exec;
var path = require('path');

function logRequest(type, req){

    logger.info("Request Received. TYPE: " + type + ", PATH: " + req.path + ", EXT-IP:" + req.ip );
}

exports.updateUserSystemID = function(req, res){

    logRequest("POST", req);

    var adminPassword = req.body.addminPassword;

    var email = req.body.email;
    var systemId = req.body.systemId;
    var environment = req.body.environment;


    if((environment && environment == 'live') && (typeof adminPassword === "undefined" || (adminPassword != adminPW))){
        logger.error("User provided incorrect admin password: " + adminPassword + ". Ext-IP: " + req.ip +
                ", Request Body: " + JSON.stringify(req.body));

        res.render("notAuthorized", { authFailed : true});
        return;
    }


    var email = req.body.email;
    var systemId = req.body.systemId;
    var environment = req.body.environment;

    var url = 'http://';

    var edSvc="ed1.uidsvc.qai.expertcity.com";
    var rcSvc="rc1.uidsvc.qai.expertcity.com";
    var stageSvc="stage.uidsvc.las.expertcity.com";
    var liveSvc="uidsvc.las.expertcity.com";



    if(environment == 'ed'){
        url = url + edSvc + '/useridresolver/rest/user?email=' + email;
    }else if(environment == 'rc'){
        url = url + rcSvc + '/useridresolver/rest/user?email=' + email;
    }else if(environment == 'stage'){
        url = url + stageSvc + '/useridresolver/rest/user?email=' + email;
    }else if(environment == 'live'){
        url = url + liveSvc + '/useridresolver/rest/user?email=' + email;
    }else{
        logger.error("Invalid environment passed: " + environment);
        res.send("Invalid environment passed: " + environment);
        return;
    }

    console.log("deleting user system id for email: " + email);
    console.log(__dirname + '/shellscripts/updateudir ' + email + ' ' + environment + ' ' + systemId);

    exec(__dirname + '/../shellscripts/updateuidr.sh ' + email + ' ' + environment + ' ' + systemId,
            function (error, stdout, stderr) {
                console.log('stdout: ' + stdout);
                console.log('stderr: ' + stderr);
                if (error !== null) {
                    console.log('exec error: ' + error);
                }

                res.render('updateUIDR',
                        { msg : "User: " + email + " has been updated in UIDR. SystemId: " + systemId  });
            });



}

exports.getUserStatusByKey = function(req, res){

    logRequest("GET", req);

	var userKey = req.params.userKey.trim();
	var env = req.query.env;
	var g2mUrl = 'gotomeeting.com';
	var restPath = '/g2mbroker/migration/rest/userstatus/';
	
	var url = '';
	
	if(env === 'live'){
		url = 'http://' + g2mUrl + restPath + userKey;
	}else{
		url = 'http://' + env + '.' + g2mUrl + restPath + userKey;
	}
	
	var userStatus = "";	
	console.log("requesting url: " + url);
	request.get({"rejectUnauthorized": false, json: false, encode: null,
			url: url },function(error, response, body) {
				
				var errorMsg = "";
                var json = "";

				if(error != null){
					console.log("Error: " + error);
					errorMsg = error;
				}else{
					var errorMsg = "";
					if(response.statusCode == 404){
						errorMsg = "User status not found for userKey: " + userKey;
					}else{

                        try{
                            json = body.replace(/(([0-9]+){8,})/g, '"$1"');
                            userStatuses = JSON.parse(json);
                        }catch(err){
                            try{
                                console.log("error: " + err);

                                json = body.replace(/(\\")/g, " ").replace(/(([0-9]+){10,})/g, '"$1"');
                                console.log(">>>  " + json);
                                userStatus = JSON.parse(json);
                            }catch(err){
                                errorMsg = err;
                                console.log("Error:" + err);

                            }
                        }

					}
				}
				res.render('userstatus', { userKey: userKey, url: url, userStatus: userStatus, 
					errorMsg: errorMsg, json : json});
	});
};

exports.sendUserMigrationEvents = function(req, res){

    logRequest("POST", req);

    var adminPassword = req.body.adminPassword;
    var env = req.query.env;
    var personalRestPath = '/queue/rest2/com.citrix.soamigration.migrateAccount+';
    var corpRestPath = '/queue/rest2/com.citrix.soamigration.corpMigrateAccount+';
    var url = '';
    var userType = req.query.userType;

    if((env && env=='live') && (typeof adminPassword === "undefined" || (adminPassword != adminPW))){
        logger.error("User provided incorrect admin password: " + adminPassword + ". Ext-IP: " + req.ip +
                ", Request Body: " + JSON.stringify(req.body));

        res.render("notAuthorized", { authFailed : true});
        return;
    }


    if(env === 'i2' || env === 'i3'){
    	url = 'http://ed1.queue1svc.qai.expertcity.com';
	}else if(env === 'qa3'){
        url = 'http://queue1rc1svc.qai.expertcity.com';
	}else if(env === 'stage'){
        url = 'http://queuestagesvc.sjc.expertcity.com';
    }else if(env === 'live'){
        url = 'http://queuesvc.sjc.expertcity.com';
    }else{
        console.log("Invalid environment: " + env);
        res.send("Invalid environment: " + env);
        return;
    }

    if(userType === 'personal'){
        url = url + personalRestPath;
    }else{
        url  = url + corpRestPath;
    }

    var newMigrationEvents = req.body.newMigrationEvents;
    var numSent = 0;

    if(newMigrationEvents && (typeof newMigrationEvents != 'undefined')){
        var errors = [];
        for(var i=0; i < newMigrationEvents.length; i++){

            if(newMigrationEvents[i].legacyUserKey === ''){
                continue;
            }
            var accountKey = newMigrationEvents[i].legacyAccountKey;
            var userKey = newMigrationEvents[i].legacyUserKey;
            var partition = newMigrationEvents[i].partition;
            var email = newMigrationEvents[i].email;
            var soaAccountKey = newMigrationEvents[i].soaAccountKey;
            var soaUserKey = newMigrationEvents[i].soaUserKey;
            var migrationStatus = newMigrationEvents[i].migrationStatus;

            var legacyObj = {
                userKey: userKey,
                accountKey: accountKey,
                partition: partition,
                email: email
            };
            var globalObj = {
                userKey: soaUserKey,
                accountKey: soaAccountKey
            }
            var postData={
                legacy: legacyObj,
                global: globalObj,
                status: migrationStatus
            };

            var postStr = "{\"legacy\":{\"userKey\":\"" + userKey +"\",\"accountKey\":\"" + accountKey +"\",\"partition\":\"" + partition +
                "\",\"email\":\"" + email + "\"},\"global\":{\"userKey\":\"" + soaUserKey + "\",\"accountKey\":\"" + soaAccountKey +"\"},\"status\":\"" + migrationStatus + "\"}";

            console.log("Sending Event: " + JSON.stringify(postData));

            request.post({
                "rejectUnauthorized": false,
                followAllRedirects : true,
                followRedirect : true,
                uri: url,
                headers:{'Content-Type': 'application/json'},
                body: postStr
            },function(err,res,body){
                console.log('RESPONSE BODY: ' + body);
                console.log(res.statusCode == 200);
                if(!err){
                    numSent = numSent + 1;
                    console.log(numSent);
                }
            });
        }

        console.log("Finished sending user migration events. Errors: " + errors);
    }

	res.send("Migration Events sent to Queue: " + url);

};