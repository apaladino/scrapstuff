
/**
 * Module dependencies.
 */

var cors = require('cors');
var express = require('express');
var routes = require('./routes');
var http = require('http');
var path = require('path');
var accountStatus = require('./routes/accountstatus');
var userStatus = require('./routes/userstatus');
var service = require('./routes/service');
var migrationOverview = require('./routes/migrationOverview');
var log4js = require('log4js');
log4js.configure({
    appenders: [{type: 'console'},
        {type: 'file',
            filename: '/var/ec/migrationtool/migration-tool-',
            category: 'dev',
            "type": "dateFile",
            "pattern": "-yyyy-MM-dd.log",
            "alwaysIncludePattern": true
        }


    ]
});

var logger = log4js.getLogger('dev');
logger.setLevel('DEBUG');

var app = express();

// all environments
app.set('port', process.env.PORT || 9999);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(express.cookieParser('your secret here'));
app.use(express.session());
app.use(app.router);
app.use(require('stylus').middleware(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'public')));
app.use(log4js.connectLogger(logger, {level: log4js.levels.DEBUG}));
app.use(cors());

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}
app.enable('trust proxy');
app.get('/', routes.index);
app.get('/accountstatus/:accountKey', accountStatus.getAccountStatusByKey);
app.get('/accountstatus/:accountKey/users', accountStatus.getUsersForAccount);
app.get('/userstatus/:userKey', userStatus.getUserStatusByKey);
app.post('/userevents', userStatus.sendUserMigrationEvents);
app.post('/service/events', service.sendServiceStatusEvent);
app.get("/overview/stats", migrationOverview.getStats)
app.get("/newaccountsjuly", migrationOverview.getNewAccountsSinceJuly);
app.get("/overview/triage/passingCandidates", migrationOverview.getTriageCounts);
app.get("/overview/triage/rollbacks", migrationOverview.getTriageRollbacks);
app.get("/overview/triage/completedperhour", migrationOverview.getTriageCompletedPerHour);
app.get("/overview/triage/candidatesperhour", migrationOverview.getTriageCandidatesPerHour);
app.get("/overview/triage/candidatescounts", migrationOverview.getTriageCandidateCounts);
app.get("/overview/triage/missingsrp", migrationOverview.getMissingSRPCandidates);
app.get("/overview/triage/completed", migrationOverview.getTriageCompletedView);
app.get("/overview/triage/counts/week", migrationOverview.getTriageCountsWeek);
app.get("/overview/triage/historysync", migrationOverview.getHistorySyncCounts);
app.get("/overview/triage", migrationOverview.getTriageCountsView);

app.get("/migratedlast30days", migrationOverview.getMigratedLast30Days);
app.get("/migrationerrors", migrationOverview.getMigrationErrors);
app.get("/sincejulycounts", migrationOverview.getCountsSinceJuly);
app.post("/user/uidr/systemid", userStatus.updateUserSystemID);
app.get("/usage", service.getUsage);

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
