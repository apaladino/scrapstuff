
/*
 * GET account status
 */
var request = require('request');
var log4js = require('log4js');
var logger = log4js.getLogger("dev");

function logRequest(type, req){

    var datetime = new Date();
    logger.info("Request Received. " + datetime + ", PATH: " + req.path + ", EXT-IP:" + req.ip );
}


exports.getAccountStatusByKey = function(req, res){

    logRequest("GET", req);

	var accountKey = req.params.accountKey.trim();
	var env = req.query.env;
	var g2mUrl = 'gotomeeting.com';
	var restPath = '/g2mbroker/migration/rest/accountstatus/';
	
	var url = '';
	
	if(env === 'live'){
		url = 'http://' + g2mUrl + restPath + accountKey;
	}else{
		url = 'http://' + env + '.' + g2mUrl + restPath + accountKey;
	}
	
	var accountStatus = "";	
	console.log("requesting url: " + url);
	request.get({"rejectUnauthorized": false, json: false, encode: null,
			url: url },function(error, response, body) {
				
				var errorMsg = "";
				if(error != null){
					console.log("Error: " + error);
					errorMsg = error;
				}else{
					var errorMsg = "";
					if(response.statusCode == 404){
						errorMsg = "Account status not found for accountKey: " + accountKey;
					}else{
                        try{
                            var json = body.replace(/(([0-9]+){8,})/g, '"$1"');

                            accountStatus = JSON.parse(json);
                        }catch(err){
                            errorMsg = "Unexpected Error: " + body;
                        }

					}
				}
				res.render('accountstatus', { accountKey: accountKey, url: url, accountStatus: accountStatus, 
					errorMsg: errorMsg});
	});
	
};

exports.getUsersForAccount = function(req, res){

    logRequest("GET", req);


	var accountKey = req.params.accountKey.trim();
	var env = req.query.env;
	var g2mUrl = 'gotomeeting.com';
	var restPath = '/g2mbroker/migration/rest/accountstatus/';
	
	var url = '';
	
	if(env === 'live'){
		url = 'https://' + g2mUrl + restPath + accountKey + '/userstatus';
	}else{
		url = 'https://' + env + '1.' + g2mUrl + restPath + accountKey + '/userstatus';
	}
	
	var userStatuses = "";	
	console.log("requesting url: " + url);

	request.get({"rejectUnauthorized": false, json: false, encode: null,
			url: url },function(error, response, body) {
				var errorMsg = "";
				if(error != null){
					console.log("Error: " + error);
					errorMsg = error;
				}else{
					var errorMsg = "";
					if(response.statusCode == 404){
						errorMsg = "User statuses not found for accountKey: " + accountKey;
					}else{
                        try{
                            var json = body.replace(/(([0-9]+){8,})/g, '"$1"');
                            userStatuses = JSON.parse(json);
                        }catch(err){
                            try{
                                var json2 = body.replace(/(\\")/g, " ").replace(/(([0-9]+){10,})/g, '"$1"');
                                console.log(">>>  " + json2);
                                userStatuses = JSON.parse(json2);
                            }catch(err){
                                errorMsg = err;
                            }
                        }
                        console.log("###" + JSON.stringify(userStatuses) + ", legth: " + userStatuses.length);
					}
				}

				var stats = { numMigrated:0, numCompleted:0, numRolledBack:0,
					numSkippedAS:0, numReady:0,numStarted:0, numCreatedAS:0};
					
				if(userStatuses != ""){
					for(var i=0; i < userStatuses.length;i++){
						if(userStatuses[i].migrationStatus === 'MIGRATED'){
							stats.numMigrated++;
						}else if(userStatuses[i].migrationStatus === 'COMPLETED'){
							stats.numCompleted++;
						}else if(userStatuses[i].migrationStatus === 'ROLLED_BACK'){
							stats.numRolledBack ++;
						}else if(userStatuses[i].migrationStatus === 'SKIPPED_AS'){
							stats.numSkippedAS++;
						}else if(userStatuses[i].migrationStatus === 'READY'){
							stats.numReady++;
						}else if(userStatuses[i].migrationStatus === 'STARTED'){
							stats.numStarted++;
						}else if(userStatuses[i].migrationStatus === 'CREATED_AS'){
                            stats.numCreatedAS++;
                        }
					}
				}
				
				res.render('userstatusesforaccount', { accountKey: accountKey, url: url, users: userStatuses, 
					errorMsg: errorMsg,
					stats: stats, rawResponse: body});
	});
	
};
