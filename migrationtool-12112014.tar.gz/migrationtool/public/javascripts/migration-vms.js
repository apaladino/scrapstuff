/*<![CDATA[*/


var GetAccountStatusModel = function (newMigrationEvents) {
    var self = this;
    self.environments = ko.observableArray(['i2', 'i3', 'qa3', 'stage', 'live']);
    self.svcEnvironments = ko.observableArray(['ed', 'rc', 'stage', 'live']);
    self.statuses = ko.observableArray(['READY', 'ROLLED_BACK', 'STARTED', 'PENDING', 'COMPLETED', 'MIGRATED', 'NOT_STARTED', 'SKIPPED_AS', 'IN_PROGRESS']);
    self.soaServices = ko.observableArray(['COMMERCE', 'MESSAGE', 'SCREENSHARING', 'USAGE', 'G2W', 'G2T', 'AUDIO', 'BI', 'RPD']);
    self.selectedSoaService = ko.observable("");
    self.soaServiceStatuses = ko.observableArray(['FAILED', 'MIGRATED', 'PENDING', 'COMPLETED']);
    self.selectedSoaServiceStatus = ko.observable("");
    self.soaServiceErrMsg = ko.observable("");
    self.selectedEnvironment = ko.observable("");
    self.selectedSvcEnvironment = ko.observable("");
    self.accountKey = ko.observable("");
    self.userKey = ko.observable("");
    self.migrationStatus = ko.observable("");
    self.soaUserKey = ko.observable("");
    self.migrationWorkflow = ko.observable("");
    self.migrationEvents = ko.observableArray(newMigrationEvents);
    self.userType = ko.observable("corporate");
    self.adminPassword=ko.observable("");
    self.email = ko.observable("");
    self.systemIDs = ko.observableArray(['G2MP1', 'G2MP2', 'G2MP3', 'G2MP4', 'ISL1', 'G2W1']);
    self.selectedSystemID = ko.observable("");

    self.sendServiceStatusEvent = function(){

        $.ajax({
            url: '/service/events/?env=' + self.selectedEnvironment(),
            data: {accountKey: self.accountKey(),
                userKey: self.userKey(),
                service: self.selectedSoaService(),
                status: self.selectedSoaServiceStatus(),
                errMsg: self.soaServiceErrMsg(),
                adminPassword: self.adminPassword()
            },
            type: 'POST',
            success: function (data) {
                $('#sendServiceStatusEventsResults').html(data);
            }
        });

    };

    self.addMigrationEvent = function () {
        self.migrationEvents.push({
            legacyUserKey: "",
            legacyAccountKey: "",
            partition: "",
            email: "",
            soaUserKey: "",
            soaAccountKey: "",
            migrationStatus: ""
        });
    };
    self.removeMigrationEvents = function (userStatus) {
        self.migrationEvents.remove(userStatus);
    };

    self.sendMigrationEvents = function () {
        var accountKey = self.accountKey();
        var newMigrationEvents = self.migrationEvents();

        $.ajax({
            url: '/userevents/?env=' + self.selectedEnvironment() + '&userType=' + self.userType(),
            data: {accountKey: self.accountKey(),
                migrationWorkflow: self.migrationWorkflow(),
                newMigrationEvents: newMigrationEvents,
                adminPassword: self.adminPassword()
            },
            type: 'POST',
            success: function (data) {
                $('#sendUserMigrationEventsResults').html(data);
            }

        });

    };

    self.getAccountStatusResults = function (form) {
        $.ajax({
            url: '/accountstatus/' + self.accountKey() + '?env=' + self.selectedEnvironment(),
            type: 'GET',
            success: function (data) {
                $('#accountStatusResults').html(data);
            }
        });
    };
    self.getUsersForAccountResults = function () {
        $.ajax({
            url: '/accountstatus/' + self.accountKey() + '/users?env=' + self.selectedEnvironment(),
            type: 'GET',
            success: function (data) {
                $('#userStatusesForAccountResults').html(data);
            }
        });
    };
    self.getInvitedUsersForAccountResults = function () {
        $.ajax({
            url: '/accountstatus/' + self.accountKey() + '/invitedusers?env=' + self.selectedEnvironment(),
            type: 'GET',
            success: function (data) {
                $('#invitedUserStatusesForAccountResults').html(data);
            }
        });
    };
    self.getUserStatusResults = function () {
        $.ajax({
            url: '/userstatus/' + self.userKey() + '?env=' + self.selectedEnvironment(),
            type: 'GET',
            success: function (data) {
                $('#getUserStatusResults').html(data);
            }
        });
    };
    self.addUserStatusResults = function () {

        $.ajax({
            url: '/userstatus/' + self.userKey() + '?env=' + self.selectedEnvironment(),
            data: {migrationStatus: self.migrationStatus(),
                soaUserKey: self.soaUserKey(),
                migrationWorkflow: self.migrationWorkflow()},
            type: 'POST',
            success: function (data) {
                $('#addUserStatusResults').html(data);
            }
        });
    };

    self.updateUIDRSystemID = function(){

        if(self.email() === ""){
            $("#errorMsgDiv").text("Please enter the user email address").show().fadeOut(3600, function(){
                $(this).remove();
            });
            return;
        }

        if(self.selectedSystemID() === ""){
            $("#errorMsgDiv").text("Please select a system ID").show().fadeOut(3600, function(){
                $(this).remove();
            });
            return;
        }

        $.ajax({
            url: '/user/uidr/systemid',
            data: {email: self.email(),
                systemId: self.selectedSystemID(),
                addminPassword: self.adminPassword(),
                environment : self.selectedSvcEnvironment()
            },
            type: 'POST',
            success: function (data) {
                $('#updateUIDRSystemIdResults').html(data);
            }
        });


    } ;

};


$(document).ready(function () {
    ko.applyBindings(new GetAccountStatusModel([
        {
            legacyUserKey: "",
            legacyAccountKey: "",
            partition: "",
            email: "",
            soaUserKey: "",
            soaAccountKey: "",
            migrationStatus: ""
        }
    ]));

});
/*]]>*/
