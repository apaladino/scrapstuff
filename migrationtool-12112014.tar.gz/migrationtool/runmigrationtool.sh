#!/bin/bash

echo "Running migration tool"

cd /Users/apaladino/dev/nodeprojects/migrationtool
node app.js
