var request = require('request');
var log4js = require('log4js');
var logger = log4js.getLogger("dev");
var adminPW = "iams0happy";
var exec = require('child_process').exec;
var path = require('path');

var IpAddress = function(ip, name){
    this.ip = ip;
    this.name = name;
};

var Request = function(date, formattedDate, path, name){
    this.date = date;
    this.formattedDate = formattedDate;
    this.path = path;
    this.name = name;
}

var PathTotals = function(date, pathTotals, userTotals){
    this.date = date;
    this.pathTotals = pathTotals;
    this.userTotals = userTotals;
}

function reverse(str){
    var s = "";
    var i = str.length;
    while (i>0) {
        s += this.substring(i-1,i);
        i--;
    }
    return s;
}

function logRequest(type, req){

    logger.info("Request Received. TYPE: " + type + ", PATH: " + req.path + ", EXT-IP:" + req.ip );
}

exports.getUsage = function(req, res){
    logRequest("GET", req);

    var ipMap = {};
    var requests = [];
    var datePathTotals = [];

    exec(__dirname +'/../shellscripts/grepip.sh',
            function (error, stdout, stderr) {
                console.log('stdout: ' + stdout);
                console.log('stderr: ' + stderr);
                if (error !== null) {
                    console.log('exec error: ' + error);
                }

                var output = stdout;
                var lines = output.split("\n");



                console.log("Loading IP Addresses");

                for(var i=0; i < lines.length; i++){
                    var line = lines[i];
                    if(line.indexOf('.in-addr.arpa') >= 0){
                        var tokens = line.split('.in-addr.arpa');

                        if(tokens[0].indexOf("** server can't find") >= 0){
                            var ip = tokens[0];
                            ip = ip.substring(ip.indexOf("find ") + 5).trim();
                            ip = ip.split(".").reverse().join(".");
                            name = tokens[1].substring(2).trim();
                            console.log("$$" + name + ",")
                            var mapping = ipMap[ip]
                            if(!mapping){
                                mapping = new IpAddress(ip, name);
                                ipMap[ip] = mapping;
                            }
                        }else{

                            var ipAddr = tokens[0].replace(",", "").trim();
                            ipAddr = ipAddr.split(".").reverse().join(".");
                            var name = tokens[1].split("=")[1].replace(".", "").trim();
                            console.log("name==="+name);
                            var mapping = ipMap[ipAddr];
                            if(!mapping){
                                mapping = new IpAddress(ipAddr, name);
                                ipMap[ipAddr] = mapping;

                            }
                        }
                    }
                }// end for loop

                // ###
                // ### LOAD and parse requests
                // ###
                console.log("\n\n## parsing requests\n\n" + JSON.stringify(ipMap, null, 2));
                exec('cat /var/ec/migrationtool/* | sort -r | grep "Request Received"',
                        function (error, stdout, stderr) {
                            if (error !== null) {
                                console.log('exec error: ' + error);
                            }

                            var output = stdout;
                            var lines = output.split("\n");
                            for(var i=0; i < lines.length; i++){
                                var line = lines[i];
                                var tokens = line.split(']');
                                var dateStr = tokens[0].replace("[", "");
                                var date = new Date(dateStr);
                                var formattedDate = dateStr.split(" ")[0].trim();
                                var subStr = line.substring(line.indexOf("PATH: ") + 6);
                                var path = subStr.substring(0, subStr.indexOf(",")).trim();
                                var extIP = subStr.substring(subStr.indexOf("EXT-IP:")+7).trim();
                                if(path == ""){
                                    continue;
                                }
                                var name = extIP;
                                var mapping = ipMap[extIP];
                               // console.log("**" + extIP + ", " + JSON.stringify(mapping, null, 2));
                                if(mapping){
                                    name = mapping.name;
                                }

                                var request = new Request(date, formattedDate, path, name);
                               // console.log("^ adding new request" + JSON.stringify(request, null, 2));
                                requests.push(request);
                            }

                            console.log("Finished loading requests. ");
                            var pathTotals = {};
                            var userTotalsDaily = {};
                            var userTotals = {};
                            var currentDate = "";
                            for(var i=0; i < requests.length; i++){
                                var request = requests[i];
                                var dt = request.formattedDate;
                                if(currentDate != dt){
                                    if(currentDate != ""){
                                        datePathTotals.push(new PathTotals(currentDate, pathTotals, userTotalsDaily));
                                        pathTotals = {};
                                        userTotalsDaily = {};
                                    }
                                    currentDate = dt;

                                }

                                // count path
                                var path = request.path;
                                path = path.replace(/[0-9]/g, "");
                                var pathCount = pathTotals[path];
                                if(!pathCount){
                                    pathCount = 0;
                                }

                                pathCount++;
                                pathTotals[path] = pathCount;

                                // count user request
                                var name = request.name;
                                var userCount = userTotalsDaily[name];
                                var userTotalCount = userTotals[name];
                                if(!userCount){
                                    userCount = 0;
                                    userTotalCount = 0;
                                }
                                userCount++;
                                userTotalsDaily[name] = userCount;
                                userTotalCount++;
                                userTotals[name] = userTotalCount;
                            }
                            console.log("Finished counting totals: " + JSON.stringify(userTotals, null, 2));
                            res.render("usage", { totals : datePathTotals,
                                totalRequests: requests.length,
                                userTotals : userTotals});

                        });
                // ###
                // END LOAD and parse requests
            });



}

exports.sendServiceStatusEvent = function(req, res){

    logRequest("POST", req);

    var adminPassword = req.body.adminPassword;
    var env = req.query.env;
    var edQueueName = 'com.citrix.soamigration.svcUpdate+';
    var queuName = 'com.citrix.soamigration.svcUpdate';

    if((env && env=='live') &&(typeof adminPassword === "undefined" || (adminPassword != adminPW))){
        logger.error("User provided incorrect admin password: " + adminPassword + ". Ext-IP: " + req.ip +
                ", Request Body: " + JSON.stringify(req.body));

        res.render("notAuthorized", { authFailed : true});
        return;
    }


    var url = '';
    if(env === 'i2' || env === 'i3'){
        url = 'http://ed1.queue1svc.qai.expertcity.com/queue/rest2/' + edQueueName;
    }else if(env === 'qa3'){
        url = 'http://queue1rc1svc.qai.expertcity.com/queue/rest2/' + queuName;
    }else if(env === 'stage'){
        url = 'http://queuestagesvc.sjc.expertcity.com/queue/rest2/' + queuName;
    }else if(env === 'live'){
        url = 'http://queuesvc.sjc.expertcity.com/queue/rest2/' + queuName;
    }else{
        console.log("Invalid environment: " + env);
        res.send("Invalid environment: " + env);
        return;
    }

    var accountKey = req.body.accountKey;
    var userKey = req.body.userKey;
    var service = req.body.service;
    var status = req.body.status;
    var errMsg = req.body.errMsg;

    if(!accountKey || (typeof accountKey === 'undefined')){
        req.send("Missing accountKey");
        return;
    }

    if(!userKey || (typeof userKey === 'undefined')){
        req.send("Missing userKey");
        return;
    }

    if(!service || (typeof service === 'undefined')){
        req.send("Missing service");
        return;
    }

    if(!status || (typeof status === 'undefined')){
        req.send("Missing status");
        return;
    }

    console.log("requesting url: " + url);

    var postStr = "{\"service\":\"" + service + "\", \"userKey\":" + userKey + ",\"accountKey\":" + accountKey + ", \"status\":\""+ status + "\"";

    if(errMsg && (typeof errMsg != 'undefined') && errMsg != ''){
        postStr = postStr + ",\"errorMsg\":\"" + errMsg + "\"";
    }
    postStr = postStr + "}";

    console.log("Sending Event: " + postStr);
    console.log("Url: " + url);

    try{
        request.post({
            "rejectUnauthorized": false,
            followAllRedirects : true,
            followRedirect : true,
            uri: url,
            headers:{'Content-Type': 'application/json'},
            body: postStr
        },function(err,res,body){
            console.log('RESPONSE BODY: ' + body);
            console.log(res.statusCode == 200);
        });
        res.send("Service status event sent successfully.");
    }catch(err){
        res.send("Unexpected error: " + err);
    }
};
